
//
//  Macro.swift
//  SwiftTemplet
//
//  Created by hsf on 2018/8/15.
//  Copyright © 2018年 BN. All rights reserved.
//

import UIKit

let kScreen_width = UIScreen.main.bounds.width;
let kScreen_height = UIScreen.main.bounds.height;
