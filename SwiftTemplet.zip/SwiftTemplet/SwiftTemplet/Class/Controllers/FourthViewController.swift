
//
//  FourthViewController.swift
//  SwiftTemplet
//
//  Created by hsf on 2018/8/10.
//  Copyright © 2018年 BN. All rights reserved.
//

import UIKit


class FourthViewController: UIViewController {
    
//    var progressView:UIAnnularProgress?

    var progress: CGFloat = 0.0;

    override func viewDidLoad() {
        super.viewDidLoad()
        self.edgesForExtendedLayout = [];
        // Do any additional setup after loading the view.
        view.backgroundColor = UIColor.white;

        let list = Array<Any>.arrayWithItemPrefix(prefix: "按钮_", count: 16, type: 0);
        
        let rect = CGRect(x: 20, y: 20, width: kScreen_width - 20.0*2, height: 0);
        let groupView = self.createView(rect: rect, list: list as! Array<String>, numberOfRow: 4, viewHeight: 30, padding: 5, type: 0);
        view.addSubview(groupView!);

        return;
        
        let viewZero = BN_ViewZero(frame: CGRect(x:20, y:20, width:kScreen_width/2, height:kScreen_width/2));
        view.addSubview(viewZero);
        
        viewZero.block { (tap, view, idx) in
            DDLog(tap as Any,view,idx);

            self.datePicker.show();
        };
        
//        self.addClockView();
        view.addSubview(progressView)
        
        
    }

    
    func addClockView(){
        let clockView = BN_ClockView(frame: CGRect(x: 20, y: 20, width: kScreen_width - 40, height: kScreen_width - 40));
        clockView.itemList = ["111","222","333","444","555","666","777","888",];
        clockView.backgroundColor = UIColor.random();
        clockView.image = UIImage(named: "beach");
        view.addSubview(clockView);
        
        clockView.aniDuration = 12;
        clockView.aniRotation(isClockwise: true, clockView.aniDuration!, MAXFLOAT, nil);
        clockView.layoutIfNeeded();//激活子视图动画
        
        clockView.layer.cornerRadius = clockView.frame.width/2.0;
        clockView.layer.masksToBounds = true;
        
        clockView.addActionHandler { (tap, sender, idx) in
            DDLog(sender);
            
        }
        
        clockView.getViewLayer();
    }
    
    
    lazy var progressView: BN_AnnularProgress = {
        let progressView = BN_AnnularProgress(frame: CGRect(x:50,y:kScreen_width/2+40,width:100,height:100));
        progressView.backgroundColor = UIColor.cyan;
        return progressView;
    }();
    
    
    lazy var datePicker:BN_DatePicker = {
        let view = BN_DatePicker(.date);
        view.block({ (sender, idx) in
            if idx == 1 {
                DDLog(view,sender.datePicker.date,idx);
                
            }
        })

//        view.block(action: { (tap, sender, idx) in
//            DDLog(tap as Any,"\n",sender,"\n",idx);
//
//            if idx == 1 {
//                if let control = sender as? BN_DatePicker {
//                    DDLog(control.datePicker.date);
//
//                }
//            }
//        });
        return view;
    }();
    
    
    func createView(rect:CGRect, list:Array<String>!, numberOfRow:Int, viewHeight:CGFloat, padding:CGFloat, type:Int) -> UIView! {
        
        let rowCount: Int = list.count % numberOfRow == 0 ? list.count/numberOfRow : list.count/numberOfRow + 1;
        
        let backView = UIView(frame: CGRect(x: rect.minX, y: rect.minY, width: rect.width, height: CGFloat(rowCount)*viewHeight + CGFloat(rowCount - 1)*padding));
        backView.backgroundColor = UIColor.green;
        
        let viewSize = CGSize(width: (backView.frame.width - CGFloat(numberOfRow - 1)*padding)/CGFloat(numberOfRow), height: viewHeight);
        for (i,value) in list.enumerated() {
            
            let x = (viewSize.width + padding) * CGFloat(i % numberOfRow);
            let y = (viewSize.height + padding) * CGFloat(i / numberOfRow);
            let rect = CGRect(x: x, y: y, width: viewSize.width, height: viewSize.height);
            
            var view: UIView;
            switch type {
            case 1:
                let imgView = UIImageView(frame: rect);
                imgView.isUserInteractionEnabled = true;
                imgView.contentMode = UIViewContentMode.scaleAspectFit;
                imgView.image = UIImage(named: value);
                
                view = imgView;

            case 2:
                let label = UILabel(frame: rect);
                label.textAlignment = NSTextAlignment.center;
                label.numberOfLines = 0;
                label.lineBreakMode = NSLineBreakMode.byCharWrapping;
                
                view = label;

            default:
                let button = UIButton(type: .custom);
                button.frame = rect;
                button.tag = i;
                button.setTitle(value, for: UIControlState.normal);
                button.titleLabel?.font = UIFont.systemFont(ofSize: 15);
                button.titleLabel?.adjustsFontSizeToFitWidth = true;
                button.titleLabel?.minimumScaleFactor = 1.0;
                button.isExclusiveTouch = true;
                
                button.setTitleColor(UIColor.black, for: UIControlState.normal);
                button.backgroundColor = UIColor.white;
                view = button;
            }
            backView.addSubview(view);
           
        }
        return backView;
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    // MARK: - touchesBegan
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {

        progress += 0.1
        if progress >= 1.0 {
            progress = 0
        }
        progressView.setProgress(progress: progress, time:0.6, animate: true)
        
    }
}
