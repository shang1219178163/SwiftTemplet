
//
//  CGRect+Helper.swift
//  SwiftTemplet
//
//  Created by hsf on 2018/9/7.
//  Copyright © 2018年 BN. All rights reserved.
//

import UIKit

extension CGRect{
    
    var orignX: CGFloat {
        get {
            return self.origin.x;
        }
        set {
            self = CGRect(x: newValue, y: self.origin.y, width: self.size.width, height: self.size.height);
        }
    }
    
    var orignY: CGFloat {
        get {
            return self.origin.y;
        }
        set {
            self = CGRect(x: self.origin.x, y: newValue, width: self.size.width, height: self.size.height);
        }
    }
    
    
   
    
}
