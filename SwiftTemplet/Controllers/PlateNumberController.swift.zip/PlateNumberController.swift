//
//  PlateNumberController.swift
//  SwiftTemplet
//
//  Created by Bin Shang on 2019/7/9.
//  Copyright © 2019 BN. All rights reserved.
//

import UIKit

import SwiftExpand

class PlateNumberController: UIViewController, PWHandlerDelegate {
  
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        title = "车牌号键盘"
        
        createBtnBarItem("Do", isLeft: false) { (tap, view, idx) in
            UIApplication.shared.keyWindow?.endEditing(true)
        }
        
        view.addSubview(textField)
        
//        textField.inputView = handler.collectionView
//        textField.inputAccessoryView = UIView(frame: CGRectMake(0, 0, 100, 40))
        
        textField.inputView = {
            let view: UIView = UIView(frame: CGRectMake(0, 0, kScreenWidth, 216))
            view.backgroundColor = UIColor.green

            return view
        }()
        textField.inputAccessoryView = {
            let view: UIView = UIView(frame: CGRectMake(0, 0, kScreenWidth, 50))
            view.backgroundColor = UIColor.red

            return view
        }()
        view.getViewLayer()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        
        textField.snp.makeConstraints { (make) in
            make.top.equalToSuperview().offset(20)
            make.left.equalToSuperview().offset(20)
            make.right.equalToSuperview().offset(-20)
            make.height.equalTo(35)
        }
    }
    
    
    //MARK: -plate
    func plateInputComplete(plate: String) {
        
    }
    
    
    //MARK: -lazy
    lazy var textField: UITextField = {
        var view = UITextField(frame: .zero)
   
        return view
    }()
    
    lazy var handler: PWHandler = {
        let keyboradHandler = PWHandler();
        keyboradHandler.setKeyBoardView(view: textField);
        keyboradHandler.textFontSize = 18;
        keyboradHandler.delegate = self;
        
        return keyboradHandler;
    }()

}
